  


  // // const math = require("./math");
  // import mult from "./math.js";
  
  // // console.log(math.add(5,10));
  // console.log(math.mult(5,10));
  // // console.log(math.subs(5,10));
  // // console.log(math.div(5,10));
  // // console.log(math.PI);
  
// console.log([]); 
console.log("1",2+3);