


const add = (a,b) => {
  return a+b;
};

const subs = (a,b) =>{
  return a-b;
};

const div = (a,b) => {
  return a/b;
};


const mult = (a,b) =>{

  return a*b;

};

const PI = 3.214;

// export defoult mult;







