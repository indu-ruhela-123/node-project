// console.log("Hyy Indu Goog Morning.");

// const fs = require('js');
// fs.writeFile("output.txt","Wirite File", (err) => {
//   if(err) console.log("Error Successfully");
  
// });
// const http = require('http');
// const server = http.createServer((req, res) => {
//   console.log(res);
//   res.end('Hyy Indu');
// });

// // server.listen(3006, () => {
// //   console.log('Server listening on port 3006');
// // });
// server.listen(5000, 'localhost', () => {
//   console.log('Server listening on http://localhost:5000/');
// });

// const http = require('http');

// const server = http.createServer((req, res) => {
//   console.log(req.url, req.method, req.headers);

//   if(req.url === '/'){

//   }else if(req.url === '/product'){

//   }else{
    
//     res.setHeader('Content-Type', 'text/html');
//   res.write('<html>');
//   res.write('<head><title>Hyy Cutie</title></head>');
//   res.write('<body><h1>Enter Your Details:</h1></body>');
  
//   res.write('</html>');
//     res.end();
//   }


//   res.setHeader('Content-Type', 'text/html');
//   res.write('<html>');
//   res.write('<head><title>Hyy Cutie</title></head>');
//   res.write('<body><h1>Enter Your Details:</h1></body>');
  
//   res.write('</html>');
//     res.end();
// });

// const PORT = 5000;
// server.listen(PORT, 'localhost', () => {
//   console.log(`Server listening on http://localhost:${PORT}/`);
// });


// console.log("hyy Indu");
// const arr = [1,2,3,4,5,6];
// console.log(arr.map((num) => num * 5));

// console.log(global);

// console.log("Hyy Cute Girl");
// globalThis.console.log("kesi ho ?");

// console.log(globalThis.process);
// globalThis.console.log(module);


// const add = require("./math");
// const mult = require("./math");

const {add,mult} = require("./math");


console.log(add(5,10));
console.log(mult(5,10));