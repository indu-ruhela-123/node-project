const path = require("path");

console.log(__dirname);
console.log(__filename);

const filePath = Path.join("folder","iwebsoul","data.txt");

console.log(filePath);


const parseData = path.parse(filepath);
const resolvedPath = path.resolve(filePath);
const extname = path.extname(filepath);
const basename = path.basename(filepath);
const dirname = path.dirname(filepath);

console.log({})

