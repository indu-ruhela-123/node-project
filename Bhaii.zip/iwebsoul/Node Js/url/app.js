import { readFile } from "fs/promises";
import { createServer } from "http";
import path from "path";
import { fileURLToPath } from "url";
import crypto from "crypto";

// Get the current directory name
const __dirname = path.dirname(fileURLToPath(import.meta.url));

// Define the server port
const PORT = 3005;
const { readFile } = require("fs/promises");

(async () => {
  const data = await readFile("example.txt", "utf8");
  console.log(data);
})();


/**
 * Serves a static file with proper content type.
 */
const serveFile = async (filePath, contentType, res) => {
  try {
    const data = await readFile(filePath);
    res.writeHead(200, { "Content-Type": contentType });
    res.end(data);
  } catch (err) {
    res.writeHead(404, { "Content-Type": "text/html; charset=utf-8" });
    res.end("<h1>404 Page Not Found</h1>");
  }
};

// Create the HTTP server
const server = createServer(async (req, res) => {
  console.log(req.method, req.url);

  if (req.method === "GET") {
    if (req.url === "/") {
      try {

        const data = await readFile(path.join("public","index.html"));
        res.writeHead(200,{"Content-Type": "text/html"});
        res.end(data);
        
      } catch (error) {
        res.writeHead(404,{"Content-Type": "text/html"});
        res.end("404 page not found");
        
      }


      await serveFile(
        path.join(__dirname, "public", "index.html"),
        "text/html; charset=utf-8",
        res
      );
    } else if (req.url === "/style.css") {
      await serveFile(
        path.join(__dirname, "public", "style.css"),
        "text/css; charset=utf-8",
        res
      );
    } else {
      res.writeHead(404, { "Content-Type": "text/html; charset=utf-8" });
      res.end("<h1>404 Page Not Found</h1>");
    }
  } else {
    res.writeHead(405, { "Content-Type": "text/html; charset=utf-8" });
    res.end("<h1>405 Method Not Allowed</h1>");
  }

  const finaShortCode = shortCode || crypto.randomBytes(4).toString("hex");
});

// Start listening on the defined port
server.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
