const fs = require('fs')

const fileName = "test.text";
const filePath = path.join(__dirname,fileName);
console.log(___dirname);
const writeFile = fs.writeFileSync(
  filePath,
  "This is the initial Data,update",
  "utf-8"
);

console.log(writeFile);