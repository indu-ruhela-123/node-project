const http = require("http");

//web server 

const server = http.createServer(( req,res) => {

  if(req.url ==="/") {

    res.write(" Hyy I am Indira Ruhela, currently working in iwebsoul ");
    res.end();
  }
 if(req.url ==="/source-code") {

    res.write(
      " Exciting New Seasons Online — Stream latest shows and dramas for free on Amazon MX Player. New episodes available now. Enjoy Unlimited Streaming of Top Content on Amazon MX Player for Free. "
    );
    res.end();
  }
  
if (req.url === "/contact") {

  res.setHeader("Content-Type","text/plain");

    res.write(
      " The most important thing is to enjoy your life—to be happy—it's all that matters. — ..."
    ); 


    res.end();
  } 

});


const PORT = 3000;
server.listen(PORT,() => {

  console.log(' Listing on PORT ${PORT}');


});