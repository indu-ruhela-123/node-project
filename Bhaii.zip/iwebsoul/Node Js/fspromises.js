const { error } = require("console");
const fs =require("fs");
const path = require("path");

const fileName = "fsPromises.txt";


const filePath = path.join(__dirname,fileName);


const file = __dirname;
fs.promises
.readdir(file)
.then((data) => console.log(data))
.catch((err) => console.error(err));



fs.promises.writeFile(filePath,'this is the initail data','utf-8')
.then(console.log("File created successfully"))
.catch((err) => console.log(err)) ;