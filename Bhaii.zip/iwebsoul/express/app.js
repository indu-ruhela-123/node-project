import express from "express";

const app = express();

app.get("/",(req,res) => res.send("hello Indu,Haw are you "));

app.get("/about",(req,res) => res.send("currently I'm working in I websoul Company "));

app.get("/contect",(req,res) => res.send("Name:Indu Ruhela \n,                email:induruhela193@gmail.com,                contect no.6267187617 " ));

app.get("/other info ",(req,res) => res.send("Add:Banagli Square Indore,                pinoce: 452016,                             contect no.9981728484 ,                         new address:Palasiya Indore" ));




const PORT = 3000;
app.listen(PORT,() =>{

  console.log('Server is running at port:${PORT}');

});
