import express from "express";
import {shortenerRoutes} from "./routes/shortner.routs.js";

const app = express();

const PORT = process.env.PORT || 3000;

app.use(express.static("public"));
app.use(express.urlencoded({ectended:true}));

app.set("view anigine", "ejs");
