// console.log("Hyy Indu");
// console.log("Good morning ");

// fullName = "Indu Ruhela";
// age = 22;
// price = 99.99;
// redius = 14;
// a = null;
// y = undefined;
// isFollow = true;
// console.log(age);
// console.log(price);
// console.log(isFollow);

// let fullName = "tony stark";
// let age  = 24;
// let totalPrice = 1000;
// console.log(fullName);
// console.log(totalPrice);

// var movieName = "Hausfull 5";
// var cost = 5;
// console.log(movieName);

// let i = 24;

// let x = BigInt("123");
// let y = Symbol("hyy");

// const student ={

//    newName : " Ruhela Indu",
//    age : 22,
//    cgpa : 8.5,
//    isPass: true,

// };

// const product ={
//     tital : "ball pen",
//     rating : 4,
//     offer : 5,
//     price : 270,

// };
// console.log(product);

// let age = 18;
// if(age>=18){
//     console.log("you can vote");

// }
// if(age<18){
//     console.log("you CANNOT vote");

// }

// let mode = "dark";
// let color;
// if(mode === "dark"){
//     color = "black";
// }
// if(mode === "light"){
//     color = "white";
// }
// console.log(color);

// let num = 10;
// if(num % 2 ===0){
//     console.log(num,"is even");

// }else{
//     console.log(num,"is odd");
// }

// let mode = "silver";
// let color;
// if(mode === "dark"){
//     color = "black";

// }else if(mode === "blue"){
//     color = "blue";

// }else if(mode === "pink"){
//     color = "pink"
// }

// console.log(color);

// LOOPS AND STRING 

// for (let count= 1; count<=5; count =count++){
//     console.log("hyy indu");
// }
// console.log("loops has ended");

// let sum = 0;
// let n = 100;
// for(let i = 1; i<=n; i++){
//     sum = sum + 1;
// }
// console.log("sum =",sum);

// let str = "java script";
// let size = 0;
// for(let i of str){
//     console.log("i =",i);
//     size++;

// }
// console.log("string size =",size);

// let student = {

//     name : "Indu Ruhela",
//     age : 22,
//     cgpa : 8.5,
//     isPass:true,

// };
// for (let key in student){
//     console.log("key",key, "value=",student[key]);
// }

// for(let num = 0; num<=100;num++){
 

// if(num%2==0){
//     console.log("num =",num);
// }else{
//     console.log("print a number")
// }
// }
// for(let num = 0; num<=100;num++){
 

// if(num%2 !==0){
//     console.log("num =",num);
// }else{
//     console.log("print a number")
// }
// }

// let gameNumber = 25;
// let userNumber = prompt("Guess the game number :");
// while(userNumber != gameNumber){

//    userNumber = prompt(" you Enter wrong number .Guess again :");

// }
// console.log("congratulations,you entered the right userNumber");

// let str = "Indu Ruhela";
// let str1 = "Bhumika";
// let str2 = "Mahi ruhela";
// console.log(str[1]);
// console.log(str1[4]);
// console.log(str2[2]);
// let specialString = 'this is a templet literel';
// console.log( specialString);

// let obj = {
//    item : "pen",
//    price:10,
// };
// console.log("the cost of ",obj.item,"is",obj.price,"rupes");
// let specialString = 'this is a template literal';
// console.log(typeof specialString);

// let str = "Mahi Ruhela";
// let obj1={
//    item:"car",
//    price:20,
// };
// let str3 = "I Love javaScript";

// let specialString ='This is a template litelar ${1+2+3}';
// console.log(specialString);

// let str = "hyy Indu ";
// str = str.toUpperCase();
// console.log(str);

// let str1 = "Hyy Indu";
// str1 = str1.toLowerCase;
// console.log(str1);

// let str2 = " I Love my self   ";
// console.log(str.trim());

// ARRAYS IN JAVASCRIPT

// let marks =[76,88,65,99,86,92];
// console.log(marks);
// console.log(marks.length);
// let heroes = ["ironman ","thor","hulk","saktiman","spyderman"];
// console.log(heroes);

// let iWebSoulTeam = ["subham sir","ravi sir ","bhumkia mam","Payal mam","Indu Ruhela","Ravi sir"]
// for(let i = 1; i<=iWebSoulTeam.lenght; i++);
// console.log(iWebSoulTeam);

// let marks = [85,97,66,78,98,99,34,22,11,87];
// let sum = 0;
// for (let val of marks){
//     sum +=val;

// }

// let avg = sum / marks.lenght;
// console.log('avg marks pf the class = ${avg}');


// Function of java script 

// function myFunction(){
//     console.log("welcome to apna collage");
//     console.log("we are learning js :");
//     console.log("we are learning js ");
// }
// myFunction();

// function sum(a,b){
//     return a+b;


// }
// const arrowSum = (a,b) => {

//     console.log( a + b );

// };

// function mul(a,b){
//     return a*b;
// }

// function countVowels(str){
//     let count = 0;
//     for(const char of str){
//         if(char == "a" || char == "e" || char =="i" || char == "o" || char == "u"  ){
//             count++;


//         }
        
//     }
//     console.log(count);
    

// }

//  let smile = document.getElementById("smile");
//  console.log(smile);

// let element = document.querySelector("p");
// console.dir(Elements);s

// let firstEl = document.querySelector(" p");
// console.dir(firstEl);

// let allEl = document.querySelectorAll(" p");
// console.dir(allEl);

// Event

let btn1 = document.querySelector("#btn1");

// btn1.onclick = () => {
//     console.log("btn1 was clicked");
//     let a = 25;
//     a++;
//     console.log(a);
// };

btn1.addEventListener("click",() =>{
    console.log("button1 was clicked");
    
});
let div = document.querySelector("dev");