 

import { MongoClient } from "mongodb";

async function main() {
  const client = new MongoClient("mongodb://localhost:27017");

  try {
    await client.connect();
    console.log("✅ Connected");

    const db = client.db("mongodb_nodejs_db");
    const userCollection = db.collection("users");

    // Delete many documents
    const result = await userCollection.deleteMany({ name: "Indu Ruhela" });
    console.log(`${result.deletedCount} documents deleted.`);

  } catch (err) {
    console.error("Error:", err);
  } finally {
    await client.close();
  }
}

main();



const result = await userCollection.deletemany({name:"Indu ruhela"});
console.log('${result.deletedCount} documents delete.');

const  my  = await usercollenction .insertMany
({name: "Radhika lahoti "});
console.log('${my.insertmany}.');

// creat chema 

 const indu = await userCollection.insertMany
 ({name:"Riya "});
 console.log('${indu.insertmany}');


 const user = await userCollection.findOne({ name: "Indu Ruhela"});

 console.log(user);
 console.log(user._id.toHexString());


  const name = await userCollection.findOne({ name: "Shubham sir"});


 const userCursor = userCollection.find();
 console.log(userCursor);







 

 

 