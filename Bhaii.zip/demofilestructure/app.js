var express = require('express');
var path = require('path');
var logger = require('morgan');
var usersRouter = require('./routes/users');
var app = express();

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'jade');

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

app.use('/api/users', usersRouter);

app.get('/',(req,res)=>{res.json('welcome to API')})
module.exports = app;