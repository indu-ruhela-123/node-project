const users = [{
    id:'1',
    name:'monika'
}, {
    id:'2',
    name:'ayushi'
},
{
    id:'3',
    name:'shubham'
}]
exports.getAllUsers = () => users;
exports.getUserById = (id) => users.find(user => user.id === id);