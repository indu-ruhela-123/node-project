const express = require('express');
const path = require('path');
const logger = require('morgan');
const connectdb = require('./config/db');
const app = express();

// Connect to MongoDB
connectdb();

// Import routes
const userRoutes = require('./routes/users');

// Middleware
app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

// Serve static files (public folder for HTML/CSS)
app.use(express.static(path.join(__dirname, 'public')));

// API Routes
app.use('/api/users', userRoutes);

// Default route → serve registration form
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public/register.html'));
});

module.exports = app;
