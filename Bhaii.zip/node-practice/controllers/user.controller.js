const userService = require('../services/user.service');

// Get All Users
exports.getAllUsers = async (req, res) => {
  try {
    const users = await userService.getAllUsers();
    return res.status(200).json(users);
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
};

// Get User By ID
exports.getUserById = async (req, res) => {
  const id = parseInt(req.params.id);

  if (isNaN(id)) {
    return res.status(400).json({ message: 'Invalid user ID' });
  }

  try {
    const user = await userService.getUserById(id);
    return res.status(200).json(user);
  } catch (error) {
    return res.status(404).json({ message: error.message });
  }
};

// Create User
exports.createUser = async (req, res) => {
  const {
    fname,
    lname,
    email,
    password,
    gender,
    age,
    city,
    state,
    country,
    address,
    status
  } = req.body;

  // Required fields validation
  if (!fname || !email || !password || !gender || !age || !city) {
    return res.status(400).json({ message: 'Required fields are missing' });
  }

  try {
    // id is auto-assigned in pre-save hook
    const newUser = await userService.createUser({
      fname,
      lname,
      email,
      password,
      gender,
      age,
      city,
      state,
      country,
      address,
      status
    });

    return res.status(201).json({
      message: 'User created successfully',
      user: newUser
    });
  } catch (error) {
    return res.status(409).json({ message: error.message });
  }
};


// Update User
exports.updateUser = async (req, res) => {
  const id = parseInt(req.params.id);

  if (isNaN(id)) {
    return res.status(400).json({ message: 'Invalid user ID' });
  }

  try {
    const updatedUser = await userService.updateUserById(id, req.body);

    if (!updatedUser) {
      return res.status(404).json({ message: 'User not found' });
    }

    return res.status(200).json({
      message: 'User updated successfully',
      user: updatedUser
    });
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
};

// Delete User
exports.deleteUserById = async (req, res) => {
  const id = parseInt(req.params.id);

  if (isNaN(id)) {
    return res.status(400).json({ message: 'Invalid user ID' });
  }

  try {
    const response = await userService.deleteUserById(id);
    return res.status(200).json(response);
  } catch (error) {
    return res.status(404).json({ message: error.message });
  }
};

exports.loginUser = async (req, res) => {
  const { email, password } = req.body;

  if(!email || !password){
    return res.status(400).json({ message: 'Email and password are required' });
  }

  try{
    const user = await userService.getUserByEmail(email);
    if(!user) return res.status(404).json({ message: 'User not found' });

    if(user.password !== password){
      return res.status(401).json({ message: 'Invalid credentials' });
    }

    return res.status(200).json({ message: 'Login successful', user });
  }catch(err){
    return res.status(500).json({ message: err.message });
  }
};
