const User = require('../models/user');

// Create User
exports.createUser = async ({ fname, lname, email, password, gender, age, city, state, country, address, status }) => {
  const newUser = new User({ fname, lname, email, password, gender, age, city, state, country, address, status });
  await newUser.save();
  return newUser;
};


// Get All Users
exports.getAllUsers = async () => {
  return await User.find().sort({ fname: 1 }); // fname ke basis pe sort
};

// Get User by Id
exports.getUserById = async (id) => {
  const user = await User.findOne({ id }); // custom id
  if (!user) {
    throw new Error('User not found');
  }
  return user;
};

// Delete User by Id
exports.deleteUserById = async (id) => {
  const result = await User.deleteOne({ id });

  if (result.deletedCount === 0) {
    throw new Error('User not found or already deleted');
  }

  return { message: 'User deleted successfully' };
};

// Update User by Id
exports.updateUserById = async (id, updateData) => {
  const updatedUser = await User.findOneAndUpdate(
    { id },                // custom id
    updateData,            // update hone wala data
    { new: true, runValidators: true } // return updated + validation
  );

  if (!updatedUser) {
    throw new Error('User not found');
  }

  return updatedUser;
};

exports.getUserByEmail = async (email) => {
  return await User.findOne({ email });
};
