const mongoose = require('mongoose');
const Counter = require('./counter');

const userSchema = new mongoose.Schema({
  id: { type: Number, unique: true }, // auto increment
  fname: String,
  lname: String,
  email: String,
  password: String,
  gender: String,
  age: Number,
  city: String,
  state: String,
  country: String,
  address: String,
  status: { type: String, enum: ['Active','Inactive'], default: 'Active' }
}, { timestamps: true });

// Pre-save hook for auto-increment
userSchema.pre('save', async function(next) {
  if (!this.isNew) return next();

  const counter = await Counter.findByIdAndUpdate(
    { _id: 'userId' },
    { $inc: { seq: 1 } },
    { new: true, upsert: true }
  );

  this.id = counter.seq;
  next();
});

const User = mongoose.model('User', userSchema);
module.exports = User;
