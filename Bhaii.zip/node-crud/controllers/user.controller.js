const userService = require('../services/user.service');

exports.getAllUsers = async (req, res) => {
  try {
    const users = await userService.getAllUsers();
    return res.status(200).json(users);
  }
   catch (error) {
    return res.status(500).json({ message: error.message });
  }
  // const users = userService.getAllUsers();
  // res.json(users);
};

exports.getUserById = async (req, res) => {
  const id = parseInt(req.params.id);

  if (isNaN(id)) {
    return res.status(400).json({ message: 'Invalid user ID' });
  }

  try {
    const user = await userService.getUserById(id);
    return res.status(200).json(user);
  } catch (error) {
    return res.status(404).json({ message: error.message });
  }
};

exports.deleteUserById = async (req, res) => {
  const id = parseInt(req.params.id);

  if (isNaN(id)) {
    return res.status(400).json({ message: 'Invalid user ID' });
  }

  try {
    const response = await userService.deleteUserById(id);
    return res.status(200).json(response);
  } catch (error) {
    return res.status(404).json({ message: error.message });
  }

  
};

// ----------------------------------------------------------------------
// exports.getUserById = (req, res) => {
//   const user = userService.getUserById(req.params.id);
//   if (user) res.json(user);
//   else res.status(404).json({ message: 'User not found' });
// };

exports.updateUserById = async (req, res) => {
  const id = parseInt(req.params.id);

  if (isNaN(id)) {
    return res.status(400).json({ message: 'Invalid user ID' });
  }

  try {
    const updatedUser = await userService.updateUserById(id, req.body);
    return res.status(200).json(updatedUser);
  } catch (error) {
    return res.status(404).json({ message: error.message });
  }
};

exports.createUser = (req, res) => {
  const { id, name, phone } = req.body;
  console.log('------------req.body:-----------', req.body); // 🔍 Debug

  if (!id || !name) {
    return res.status(400).json({ message: 'Id and name are required' });
  }

  try {
    const newUser = userService.createUser(id, name, phone); // ✅ Pass id and name
    return res.status(201).json({
      message: 'User created successfully',
      user: newUser
    });
  } catch (error) {
    return res.status(409).json({ message: error.message });
  }
  exports.insertOneUser = (req,res) => {
    const {id,name} = req.body;
    console.log('........insert id.....',req.body);
    if(!id || !name){
      return res.status(400).json({message: 'Id and name are required'});
    }
    try {
      const newUser = userService.insertOne(id,name,phone);
      return res.status(201).json({
        message:' user insertONesuccessfulyy',
        user:newUser
      });
    } catch(error){
      return res.status(409).json({message: error.massage})
    }
  }

  
};
    
