const User = require('../models/user');

exports.createUser = async (id, name, phone, age, city, email) => {
  const existing = await User.findOne({ id });
  if (existing) {
    throw new Error('User already exists');
  }

  const newUser = new User({ id, name, phone, age, city, email });
  await newUser.save();
  return newUser;
};

exports.getAllUsers = async () => {
  return await User.find().sort({ name: 1 });
};

exports.getUserById = async (id) => {
  const user = await User.findOne({ id }); // not _id, use custom 'id'
  if (!user) {
    throw new Error('User not found');
  }
  return user;  
};

exports.deleteUserById = async (id) => {
  const result = await User.deleteOne({ id });

  if (result.deletedCount === 0) {
    throw new Error('User not found or already deleted');
  }

  return { message: 'User deleted successfully' };
};

exports.updateUserById = async (id, updateData) => {
  const updatedUser = await User.findOneAndUpdate(
    { id },          // custom id, not _id
    updateData,
    { new: true }    // return updated user
  );

  if (!updatedUser) {
    throw new Error('User not found');
  }

  return updatedUser;
};
// exports.getUserCountByAge = async (req, res) => {
  // return await User.aggregate([
  //   {
  //     $group: {
  //       _id: null,
  //       averageAge: { $avg: "$age" }
  //     }
  //   },
  //   {
  //     $project: {
  //       _id: 0,
  //       averageAge: { $round: ["$averageAge", 2] }
  //     }
  //   }
  // ]);
 exports.getMostCommonNamesByCity = async () => {
  return await User.aggregate([
    {
      $match: {
        age: { $gte: 35 }
      }
    },
    {
      $group: {
        _id: { city: "$city", name: "$name" },
        count: { $sum: 1 }
      }
    },
    {
      $sort: {
        "_id.city": 1,
        count: -1
      }
    },
    {
      $group: {
        _id: "$_id.city",
        topName: { $first: "$_id.name" },
        count: { $first: "$count" }
      }
    },
    {
      $project: {
        _id: 0,
        city: "$_id",
        name: "$topName",
        count: 1
      }
    }
  ]);
};

// const users = [{    id:'1',   name:'monika'},
//   {    id:'2',    name:'ayushi'},
// ]
// exports.getAllUsers = () => users;
// exports.getUserById = (id) => users.find(user => user.id === id);
// exports.createUser = (id, name) => {
//   if (!id || !name) {
//     throw new Error('ID and name are required');
//   }

//   const existing = users.find(u => u.id === id);
//   if (existing) {
//     throw new Error('User already exists');
//   }

//   const newUser = { id, name };
//   // const newUsers = (newItem) => users.push(newUsers);
//   users.push(newUser);
//   // const user2 = newUser.slice();
//   // newUser.splice(0,1);
//   console.log(users.pop(1));
//   console.log(users.length,"----------------users length----------------------");
//   return newUser;
//   function removeLastItem(){
//     newUser.pop();
//   }
//   console.log(removeLastItem());
//   console.log(newUser,"hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh")
// };


