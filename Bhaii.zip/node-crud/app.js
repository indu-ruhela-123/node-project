const express = require('express');
const path = require('path');
const logger = require('morgan');
const connectdb = require('./config/db');
const app = express();

connectdb();
const userRoutes = require('./routes/users');

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

// Routes
app.use('/api/users', userRoutes);

// Default route
app.get('/', (req, res) => {
  res.json({ message: 'Welcome to the API' });
});


module.exports = app;