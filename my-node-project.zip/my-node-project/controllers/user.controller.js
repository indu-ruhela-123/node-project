const userService = require('../services/user.service');

exports.getAllUsers = (req, res ) =>{
const users = userService.getAllUsers();
res.json(users);
}

exports.getUserById = (req, res ) =>{
  const user = userService.getUserById(req.params.id);
  if(user) res.json(user);
  else res.status(404).json({message:"user not found"})
}
