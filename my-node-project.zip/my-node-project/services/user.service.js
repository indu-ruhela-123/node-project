const users = [{
    id:'1',
    name:'indumati'
}, {
    id:'2',
    name:'bhumika'
},
{
    id:'3',
    name:'shubham'
},
{
    id:'4',
    name:'Ravi'
}
]
exports.getAllUsers = () => users;
exports.getUserById = (id) => users.find(user => user.id === id);